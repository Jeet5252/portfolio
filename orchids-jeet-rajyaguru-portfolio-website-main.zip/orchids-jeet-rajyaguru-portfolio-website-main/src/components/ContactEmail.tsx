import * as React from 'react';

interface ContactEmailProps {
  name: string;
  email: string;
  message: string;
}

export const ContactEmail: React.FC<Readonly<ContactEmailProps>> = ({
  name,
  email,
  message,
}) => (
  <div style={{ fontFamily: 'sans-serif', padding: '20px', color: '#333' }}>
    <h1 style={{ color: '#4f46e5' }}>New Message from Portfolio</h1>
    <p><strong>Name:</strong> {name}</p>
    <p><strong>Email:</strong> {email}</p>
    <p><strong>Message:</strong></p>
    <div style={{ 
      backgroundColor: '#f9fafb', 
      padding: '15px', 
      borderRadius: '8px', 
      border: '1px solid #e5e7eb',
      whiteSpace: 'pre-wrap'
    }}>
      {message}
    </div>
  </div>
);
