'use server';

import { Resend } from 'resend';
import { createClient } from '@supabase/supabase-js';
import { ContactEmail } from '@/components/ContactEmail';
import * as React from 'react';

// Use service role key for server-side operations to bypass RLS
const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

const resend = new Resend(process.env.RESEND_API_KEY);

export async function submitContactForm(data: { name: string; email: string; message: string; }) {
  try {
    console.log('Starting form submission for:', data.email);

    // 1. Save to Supabase
    const { error: dbError } = await supabaseAdmin
      .from('messages')
      .insert([
        { 
          name: data.name, 
          email: data.email, 
          message: data.message 
        }
      ]);

    if (dbError) {
      console.error('Database error:', dbError);
      throw new Error(`Failed to save to database: ${dbError.message}`);
    }

    console.log('Successfully saved to database');

    // 2. Send email via Resend
    // We use JSX directly here since we are in a .tsx file
    const { error: emailError } = await resend.emails.send({
      from: 'Portfolio Contact <onboarding@resend.dev>',
      to: ['jeetrajyaguru18@gmail.com'],
      replyTo: data.email,
      subject: `New Message from ${data.name}`,
      react: <ContactEmail name={data.name} email={data.email} message={data.message} />,
    });

    if (emailError) {
      console.error('Resend error:', emailError);
      // We return success true because it's saved in DB, but we want to know about email failure
      return { success: true, emailError: true };
    }

    console.log('Successfully sent email');
    return { success: true };
  } catch (error: any) {
    console.error('Form submission error:', error);
    return { 
      success: false, 
      error: error.message || 'Something went wrong. Please try again later.' 
    };
  }
}
