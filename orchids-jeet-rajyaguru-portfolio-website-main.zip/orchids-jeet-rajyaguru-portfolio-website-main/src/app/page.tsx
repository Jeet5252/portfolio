"use client";

import * as React from "react";
import Link from "next/link";
import Image from "next/image";
import { motion, useScroll, useTransform } from "framer-motion";
import {
  Code,
  Palette,
  Megaphone,
  ArrowRight,
  Mail,
  Target,
  Zap,
  Sparkles,
  Instagram,
  MessageSquare,
  Rocket,
  ArrowDownRight,
  Globe,
  Layers,
  Cpu,
  Smartphone,
  Trophy,
  BookOpen,
  Eye,
  Activity,
  UserCheck,
  ZapIcon,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Navbar } from "@/components/Navbar";
import { ContactForm } from "@/components/ContactForm";

const fadeIn = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] },
};

const stagger = {
  animate: {
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const skillCategories = [
  {
    category: "Technical & Digital",
    icon: <Code className="h-6 w-6 text-cyan-400" />,
    items: ["Web development (Frontend)", "UI design fundamentals", "Python fundamentals"],
    color: "from-cyan-500/20 to-blue-500/20",
    accent: "bg-cyan-500",
  },
  {
    category: "Content & Creative",
    icon: <Palette className="h-6 w-6 text-rose-400" />,
    items: ["Instagram content creation", "Short form video editing", "Thumbnail design", "Engagement captions"],
    color: "from-rose-500/20 to-orange-500/20",
    accent: "bg-rose-500",
  },
  {
    category: "Marketing & Outreach",
    icon: <Megaphone className="h-6 w-6 text-emerald-400" />,
    items: ["Lead generation", "LinkedIn DM outreach", "Personal branding"],
    color: "from-emerald-500/20 to-teal-500/20",
    accent: "bg-emerald-500",
  },
  {
    category: "Core Strengths",
    icon: <Trophy className="h-6 w-6 text-amber-400" />,
    items: ["Strong academic discipline", "Consistency & Motivation", "Clear communication", "Fast learner"],
    color: "from-amber-500/20 to-orange-500/20",
    accent: "bg-amber-500",
  },
];

const comingSoonProjects = [
  {
    title: "Vision UI",
    description: "A high-fidelity minimalist design system focused on clarity, accessibility, and modern aesthetics.",
    gradient: "from-indigo-600/20 to-cyan-600/20",
    tag: "PROTOTYPING",
    icon: <Palette className="h-6 w-6" />,
  },
  {
    title: "J.A.R.V.I.S",
    description: "Personal AI assistant developed in Python, featuring voice-activated control and system automation.",
    gradient: "from-purple-600/20 to-rose-600/20",
    tag: "CORE DEVELOPMENT",
    icon: <Cpu className="h-6 w-6" />,
  },
  {
    title: "Growth Catalyst",
    description: "Data-driven digital marketing framework for strategic brand outreach and lead generation.",
    gradient: "from-emerald-600/20 to-teal-600/20",
    tag: "STRATEGY",
    icon: <Megaphone className="h-6 w-6" />,
  },
];

const roadmap = [
  {
    title: "Knowledge",
    content: "Deep diving into books and technical foundations to build a solid base of excellence.",
    icon: <BookOpen className="h-6 w-6 text-amber-400" />,
    color: "text-amber-400",
  },
  {
    title: "Experience",
    content: "Applying knowledge through hands-on building and real-world digital creation.",
    icon: <ZapIcon className="h-6 w-6 text-rose-400" />,
    color: "text-rose-400",
  },
  {
    title: "Impact",
    content: "Creating meaningful value through a strong personal brand and specialized skills.",
    icon: <Target className="h-6 w-6 text-indigo-400" />,
    color: "text-indigo-400",
  },
];

export default function Portfolio() {
  const { scrollYProgress } = useScroll();

  return (
    <div className="min-h-screen bg-[#020202] text-white selection:bg-indigo-500/30 selection:text-indigo-200 overflow-x-hidden">
      {/* Dynamic Background */}
      <div className="fixed inset-0 bg-[#020202] pointer-events-none" />
      <div className="fixed inset-0 mesh-gradient opacity-20 pointer-events-none" />
      <div className="fixed inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-[0.15] pointer-events-none mix-blend-overlay" />
      
      {/* Static Glow Orbs */}
      <div className="fixed top-[-10%] left-[-10%] w-[50%] h-[50%] bg-indigo-600/10 blur-[120px] rounded-full pointer-events-none" />
      <div className="fixed bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-rose-600/10 blur-[120px] rounded-full pointer-events-none" />

      <Navbar />

      <main className="relative container mx-auto px-4 pt-24 pb-16 sm:px-6 lg:px-8">
        {/* Hero Section */}
        <section id="hero" className="flex min-h-[90vh] flex-col justify-center py-20 lg:py-0">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            <motion.div
              initial="initial"
              animate="animate"
              variants={stagger}
              className="lg:col-span-7 relative z-40 lg:pr-12"
            >
              <motion.div variants={fadeIn}>
                <Badge variant="outline" className="mb-8 border-white/10 bg-white/5 text-zinc-300 px-6 py-2.5 text-xs font-bold uppercase tracking-[0.3em] backdrop-blur-md rounded-full">
                  <Target className="mr-2 h-4 w-4 text-cyan-400" />
                  Disciplined & Purpose Driven
                </Badge>
              </motion.div>
              <motion.h1
                variants={fadeIn}
                className="text-6xl font-black tracking-tighter sm:text-8xl lg:text-[6.5rem] xl:text-[7.5rem] leading-[0.8] uppercase mb-12 relative z-50 font-bebas"
              >
                Jeet <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-indigo-500 to-rose-500">Rajyaguru</span>
              </motion.h1>
              <motion.p
                variants={fadeIn}
                className="mt-8 text-xl font-light text-zinc-400 sm:text-2xl max-w-2xl leading-relaxed relative z-10 font-sans"
              >
                Driven by <span className="text-white font-medium">discipline</span> and <span className="text-white font-medium">purpose</span>. Building the future through continuous learning, digital creation, and a relentless pursuit of excellence.
              </motion.p>
              <motion.div variants={fadeIn} className="mt-14 flex flex-wrap gap-6">
                <motion.div whileHover={{ scale: 1.05, y: -5 }} whileTap={{ scale: 0.95 }}>
                  <Button size="lg" asChild className="rounded-full px-14 h-18 text-xl font-bold uppercase tracking-widest bg-white text-black hover:bg-cyan-500 hover:text-white transition-all duration-500 shadow-xl group">
                    <Link href="#about">
                      <span className="relative z-10 flex items-center">
                        Explore Vision <ArrowRight className="ml-3 h-6 w-6 group-hover:translate-x-2 transition-transform duration-500" />
                      </span>
                    </Link>
                  </Button>
                </motion.div>
                <motion.div whileHover={{ scale: 1.05, y: -5 }} whileTap={{ scale: 0.95 }}>
                  <Button size="lg" variant="outline" asChild className="rounded-full px-14 h-18 text-xl font-bold uppercase tracking-widest border-white/20 bg-white/5 hover:bg-white/10 backdrop-blur-md transition-all group">
                    <Link href="#contact" className="flex items-center">
                      Get In Touch <MessageSquare className="ml-3 h-6 w-6 group-hover:scale-110 transition-transform duration-500 text-rose-400" />
                    </Link>
                  </Button>
                </motion.div>
              </motion.div>
            </motion.div>
            
            <motion.div 
              className="lg:col-span-5 relative"
              initial={{ opacity: 0, scale: 0.9, rotate: 2 }}
              animate={{ opacity: 1, scale: 1, rotate: 0 }}
              transition={{ duration: 1, delay: 0.4, ease: [0.22, 1, 0.36, 1] }}
            >
              <div className="relative aspect-[4/5] w-full max-w-[500px] mx-auto group">
                <div className="absolute inset-0 bg-cyan-500 blur-[120px] opacity-10 group-hover:opacity-30 transition-opacity rounded-full animate-pulse-slow" />
                <div className="relative h-full w-full rounded-[4rem] overflow-hidden border border-white/20 shadow-[0_40px_100px_rgba(0,0,0,0.8)] transition-all duration-1000 group-hover:border-cyan-500/50 group-hover:scale-[1.02]">
                  <motion.div
                    style={{ scale: useTransform(scrollYProgress, [0, 0.2], [1, 1.15]) }}
                    className="h-full w-full"
                  >
                    <Image 
                      src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/render/image/public/project-uploads/ba2514eb-a7eb-451a-b29d-1a89be6a7be3/jeet-1767547475079.jpg?width=1000&height=1500&resize=contain"
                      alt="Jeet Rajyaguru"
                      fill
                      className="object-cover transition-all duration-1000 group-hover:scale-110"
                      priority
                    />
                  </motion.div>
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent opacity-80" />
                  <div className="absolute bottom-10 left-10 right-10 translate-y-4 group-hover:translate-y-0 transition-all duration-700">
                    <div className="flex items-center gap-3 text-white/90 font-black uppercase tracking-[0.4em] text-[10px]">
                      <div className="h-2 w-2 rounded-full bg-cyan-400 animate-pulse" />
                      Based in Vadodara, Gujarat
                    </div>
                  </div>
                </div>
                
                <motion.div 
                  animate={{ y: [0, -10, 0], rotate: [0, 5, 0] }}
                  transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
                  className="absolute -top-6 -right-6 glass p-6 rounded-3xl border border-white/20 shadow-3xl backdrop-blur-3xl z-30"
                >
                  <Rocket className="h-12 w-12 text-rose-500" />
                </motion.div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* About Section */}
        <section id="about" className="py-32 border-t border-white/5">
          <div className="grid grid-cols-1 gap-20 lg:grid-cols-2 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
              viewport={{ once: true, margin: "-100px" }}
              className="relative order-2 lg:order-1 group"
              whileHover={{ scale: 1.01 }}
            >
              <div className="relative aspect-square sm:aspect-video lg:aspect-[4/5] rounded-[4rem] overflow-hidden border border-white/20 shadow-[0_40px_100px_rgba(0,0,0,0.6)] transition-all duration-1000 group-hover:border-rose-500/30">
                <motion.div 
                  style={{ scale: useTransform(scrollYProgress, [0.2, 0.5], [1, 1.15]) }}
                  className="h-full w-full"
                >
                  <Image 
                    src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/render/image/public/project-uploads/ba2514eb-a7eb-451a-b29d-1a89be6a7be3/WhatsApp-Image-2026-01-04-at-22.53.53-resized-1767547472134.jpeg?width=1200&height=1600&resize=contain"
                    alt="Jeet on Motorcycle"
                    fill
                    className="object-cover transition-all duration-1000 group-hover:scale-105"
                  />
                </motion.div>
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent">
                   <motion.div 
                     initial={{ opacity: 0, y: 30 }}
                     whileInView={{ opacity: 1, y: 0 }}
                     transition={{ delay: 0.3, duration: 0.8 }}
                     className="absolute bottom-12 left-12 right-12 text-3xl font-black italic tracking-tight leading-tight sm:text-4xl font-bebas"
                   >
                     "I believe <span className="text-cyan-400">excellence</span> is built through <span className="text-rose-500 underline decoration-rose-500/30 underline-offset-8">discipline</span> and purpose."
                   </motion.div>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
              viewport={{ once: true }}
              className="order-1 lg:order-2"
            >
              <Badge className="mb-8 bg-rose-500 text-white border-none px-8 py-2.5 rounded-full text-[10px] font-bold uppercase tracking-[0.4em] shadow-lg font-sans">
                The Persona
              </Badge>
              <h2 className="text-6xl font-black tracking-tighter sm:text-7xl mb-10 leading-[0.85] uppercase font-bebas">
                Jeet <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-indigo-400 to-violet-500">Rajyaguru.</span>
              </h2>
              <div className="space-y-10 text-xl text-zinc-400 leading-relaxed font-light font-sans">
                <p>
                  I am a driven individual focused on building <span className="text-white font-medium italic underline decoration-cyan-500/30 underline-offset-8">practical skills</span> through continuous <span className="text-white font-medium italic underline decoration-rose-500/30 underline-offset-8">learning and application</span>.
                </p>
                <p>
                  I believe true growth comes from a combination of reading books, gaining real-world experience, and consistent self-improvement. My journey is centered around learning, building, and creating in the technology space.
                </p>
                <div className="pt-10 grid grid-cols-1 sm:grid-cols-2 gap-12">
                  <motion.div 
                    whileHover={{ x: 10 }}
                    className="group p-8 rounded-3xl bg-white/5 border border-white/10 hover:border-cyan-500/30 transition-all duration-500"
                  >
                    <div className="text-white font-bold text-3xl mb-2 group-hover:text-cyan-400 transition-all uppercase tracking-tighter font-bebas">Self-Motivated</div>
                    <div className="text-[10px] text-zinc-500 uppercase tracking-[0.5em] font-bold group-hover:text-cyan-400/50 transition-colors font-sans">Consistency</div>
                  </motion.div>
                  <motion.div 
                    whileHover={{ x: 10 }}
                    className="group p-8 rounded-3xl bg-white/5 border border-white/10 hover:border-rose-500/30 transition-all duration-500"
                  >
                    <div className="text-white font-bold text-3xl mb-2 group-hover:text-rose-500 transition-all uppercase tracking-tighter font-bebas">Fast Learner</div>
                    <div className="text-[10px] text-zinc-500 uppercase tracking-[0.5em] font-bold group-hover:text-rose-500/50 transition-colors font-sans">Growth Mindset</div>
                  </motion.div>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Skills Section */}
        <section id="skills" className="py-32">
          <div className="mb-24 flex flex-col md:flex-row md:items-end justify-between gap-12">
            <div className="max-w-4xl">
              <h2 className="text-6xl font-black tracking-tighter sm:text-9xl mb-8 uppercase leading-none font-bebas">
                The <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-emerald-400">Toolkit</span>
              </h2>
              <p className="text-zinc-400 text-2xl font-light leading-relaxed max-w-2xl font-sans">
                Combining technical fundamentals with creative execution and strategic outreach.
              </p>
            </div>
          </div>
          
          <div className="grid grid-cols-1 gap-10 md:grid-cols-2">
            {skillCategories.map((skill, index) => (
              <motion.div
                key={skill.category}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.1, ease: [0.22, 1, 0.36, 1] }}
                viewport={{ once: true, margin: "-50px" }}
                whileHover={{ y: -15 }}
              >
                <div className={`glass h-full p-12 rounded-[4rem] relative overflow-hidden group border border-white/5 hover:border-white/20 shadow-2xl transition-all duration-700`}>
                   <div className={`absolute inset-0 bg-gradient-to-br ${skill.color} opacity-0 group-hover:opacity-100 transition-opacity duration-1000`} />
                   <div className="relative z-10">
                    <div className="mb-8 inline-flex h-20 w-20 items-center justify-center rounded-3xl bg-white/5 border border-white/10 group-hover:bg-white/10 transition-all duration-700">
                      {skill.icon}
                    </div>
                    <h3 className="text-3xl font-black mb-8 uppercase tracking-tighter">{skill.category}</h3>
                    <ul className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                      {skill.items.map((item, i) => (
                        <li key={item} className="flex items-center text-zinc-500 group-hover:text-zinc-100 transition-colors">
                          <div className={`h-1.5 w-1.5 rounded-full mr-4 ${skill.accent}`} />
                          <span className="font-light text-lg">{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Vision Section */}
        <section id="vision" className="py-32">
           <div className="glass rounded-[5rem] overflow-hidden p-20 md:p-32 relative border border-white/5 shadow-3xl bg-black/60 backdrop-blur-3xl">
              <div className="absolute top-[-10%] right-[-10%] w-[60%] h-[60%] bg-indigo-600/10 rounded-full blur-[150px] animate-pulse-slow" />
              
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 1.2 }}
                viewport={{ once: true }}
                className="relative z-10 text-center mb-32"
              >
                <Badge className="mb-10 bg-white/5 text-zinc-500 border border-white/10 px-10 py-3 rounded-full text-xs font-bold uppercase tracking-[0.6em] font-sans">Vision</Badge>
                <h2 className="text-7xl font-black tracking-tighter sm:text-[11rem] mb-12 leading-none uppercase font-bebas">
                  The <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-cyan-400">Roadmap</span>
                </h2>
                <p className="text-zinc-400 text-3xl font-light max-w-4xl mx-auto leading-relaxed font-sans">
                  To continuously learn, build, and grow by combining knowledge with hands-on experience.
                </p>
              </motion.div>

              <div className="grid grid-cols-1 gap-24 md:grid-cols-3 relative z-10">
                {roadmap.map((goal, index) => (
                  <motion.div
                    key={goal.title}
                    initial={{ opacity: 0, y: 50 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8, delay: index * 0.2, ease: [0.22, 1, 0.36, 1] }}
                    viewport={{ once: true }}
                    className="flex flex-col items-center text-center group"
                  >
                    <div className="mb-14 inline-flex h-28 w-28 items-center justify-center rounded-[3rem] bg-white/5 border border-white/10 shadow-3xl group-hover:bg-white/10 transition-all duration-700">
                      {goal.icon}
                    </div>
                    <h3 className={`text-3xl font-black mb-10 uppercase tracking-widest ${goal.color} font-bebas`}>{goal.title}</h3>
                    <p className="text-zinc-500 text-2xl leading-relaxed font-light group-hover:text-zinc-100 transition-colors duration-700 max-w-sm font-sans">{goal.content}</p>
                  </motion.div>
                ))}
              </div>
           </div>
        </section>

        {/* Projects Section - YOUR WORK */}
        <section id="projects" className="py-32">
          <div className="relative mb-24">
            <h2 className="text-6xl font-black tracking-tighter sm:text-9xl mb-8 uppercase leading-none font-bebas">
              Your <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-rose-500">Work</span>
            </h2>
            <p className="text-zinc-400 text-2xl font-light max-w-3xl leading-relaxed font-sans">
              Engineering the next generation of digital assets. These projects represent my focus on technical and creative excellence.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
            {comingSoonProjects.map((project, index) => (
              <motion.div
                key={project.title}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="group relative cursor-auto"
              >
                <div className="h-full p-12 rounded-[3.5rem] border border-white/5 bg-black/40 backdrop-blur-3xl hover:border-white/20 transition-all duration-1000 flex flex-col justify-between min-h-[500px] overflow-hidden group hover:scale-[1.02] cursor-auto">
                  <div className={`absolute inset-0 bg-gradient-to-br ${project.gradient} opacity-0 group-hover:opacity-10 transition-opacity duration-1000`} />
                  
                  {/* Grainy Noise Overlay */}
                  <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-[0.05] pointer-events-none mix-blend-overlay" />

                  <div className="relative z-10">
                    <div className="flex justify-between items-center mb-12">
                      <div className="flex items-center gap-3">
                        <Activity className="h-4 w-4 text-cyan-400 animate-pulse" />
                        <span className="text-[10px] font-bold tracking-[0.4em] text-cyan-400 uppercase">
                          System Status: {project.tag}
                        </span>
                      </div>
                    </div>
                    
                    <h3 className="text-5xl font-black mb-8 leading-tight uppercase tracking-tighter text-white/40 group-hover:text-white transition-all duration-1000 blur-[2px] group-hover:blur-0">
                      {project.title}
                    </h3>
                    <p className="text-zinc-600 text-xl font-light leading-relaxed group-hover:text-zinc-400 transition-all duration-1000">
                      {project.description}
                    </p>
                  </div>

                  <div className="relative z-10 mt-12">
                    <div className="flex flex-col gap-6">
                      <div className="h-[2px] w-full bg-white/5 relative overflow-hidden">
                        <motion.div 
                          initial={{ x: "-100%" }}
                          whileInView={{ x: "0%" }}
                          transition={{ duration: 1.5, delay: 0.5 }}
                          className="absolute inset-0 bg-gradient-to-r from-transparent via-cyan-500 to-transparent"
                        />
                      </div>
                      <div className="flex items-center justify-between text-[10px] font-black uppercase tracking-[0.5em] text-zinc-700 group-hover:text-zinc-500 transition-colors">
                        <span>Revealing</span>
                        <div className="flex gap-1">
                          <span className="animate-bounce delay-0 text-cyan-500">.</span>
                          <span className="animate-bounce delay-150 text-indigo-500">.</span>
                          <span className="animate-bounce delay-300 text-rose-500">.</span>
                        </div>
                        <span>Soon</span>
                      </div>
                    </div>
                    
                    <motion.div 
                      className="mt-10 p-4 rounded-2xl border border-white/5 bg-white/5 flex items-center justify-between opacity-0 group-hover:opacity-100 transition-all duration-700 translate-y-4 group-hover:translate-y-0"
                    >
                      <span className="text-[10px] font-bold uppercase tracking-widest text-zinc-400">Request Protocol</span>
                      <Link href="#contact" className="text-white hover:text-cyan-400 transition-colors">
                        <ArrowRight className="h-5 w-5" />
                      </Link>
                    </motion.div>
                  </div>
                  
                  {/* Decorative Scanline */}
                  <div className="absolute inset-0 pointer-events-none overflow-hidden opacity-10 group-hover:opacity-20 transition-opacity">
                    <div className="h-1/2 w-full bg-gradient-to-b from-transparent via-white/5 to-transparent animate-scanline" />
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="py-32 scroll-mt-24">
          <div className="grid grid-cols-1 gap-24 lg:grid-cols-2 items-start">
            <div className="space-y-16">
              <div className="inline-block h-3 w-32 bg-gradient-to-r from-cyan-500 via-indigo-500 via-purple-500 to-rose-500 mb-6 rounded-full" />
              <h2 className="text-6xl font-black tracking-tighter sm:text-7xl lg:text-9xl mb-10 leading-none uppercase">
                Let's <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-indigo-500 via-fuchsia-500 to-rose-500">Work.</span>
              </h2>
              <p className="text-3xl text-zinc-400 font-light leading-relaxed mb-20 max-w-2xl">
                I am focused on delivering high-quality digital solutions. If you have a project in mind, <span className="text-white font-medium italic underline decoration-cyan-500/30 underline-offset-8">feel free to reach out</span>.
              </p>
              
              <div className="space-y-8">
                <motion.a 
                  href="https://www.instagram.com/j3et_rajyaguru/"
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ x: 15, scale: 1.02 }}
                  className="group flex items-center gap-8 p-6 rounded-[3rem] transition-all bg-white/5 border border-white/10 hover:border-rose-500/50 hover:bg-rose-500/5 w-fit pr-12 shadow-2xl backdrop-blur-md"
                >
                  <div className="flex h-20 w-20 flex-shrink-0 items-center justify-center rounded-[1.8rem] bg-gradient-to-tr from-[#f09433] via-[#dc2743] to-[#bc1888] text-white shadow-xl group-hover:scale-110 transition-transform duration-700">
                    <Instagram className="h-10 w-10" />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[11px] font-bold text-zinc-500 uppercase tracking-[0.5em] mb-2">Social</span>
                    <span className="text-2xl font-bold group-hover:text-white transition-all">
                      @j3et_rajyaguru
                    </span>
                  </div>
                </motion.a>

                <motion.a 
                  href="mailto:jeetrajyaguru18@gmail.com"
                  whileHover={{ x: 15, scale: 1.02 }}
                  className="group flex items-center gap-8 p-6 rounded-[3rem] transition-all bg-white/5 border border-white/10 hover:border-cyan-500/50 hover:bg-cyan-500/5 w-fit pr-12 shadow-2xl backdrop-blur-md"
                >
                  <div className="flex h-20 w-20 flex-shrink-0 items-center justify-center rounded-[1.8rem] bg-gradient-to-tr from-cyan-400 to-indigo-600 text-white shadow-xl group-hover:scale-110 transition-transform duration-700">
                    <Mail className="h-10 w-10" />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[11px] font-bold text-zinc-500 uppercase tracking-[0.5em] mb-2">Email</span>
                    <span className="text-2xl font-bold group-hover:text-white transition-all">
                      jeetrajyaguru18@gmail.com
                    </span>
                  </div>
                </motion.a>
              </div>
            </div>
            
            <div className="relative group lg:mt-0 mt-20">
              <div className="absolute -inset-2 bg-gradient-to-r from-cyan-500 via-indigo-500 via-purple-500 to-rose-500 rounded-[5rem] blur-2xl opacity-10 group-hover:opacity-30 transition duration-1000 group-hover:duration-500" />
              <div className="rounded-[5rem] p-12 lg:p-20 border border-white/10 relative overflow-hidden shadow-[0_50px_100px_rgba(0,0,0,0.7)] bg-black/80 backdrop-blur-3xl">
                <ContactForm />
              </div>
            </div>
          </div>
        </section>

        {/* Final Statement Section */}
        <section className="py-20 relative">
          <div className="relative z-10 flex flex-col items-center text-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1 }}
              className="mb-12"
            >
              <div className="h-px w-64 bg-gradient-to-r from-transparent via-zinc-800 to-transparent mx-auto mb-12" />
              <Badge className="bg-white/5 text-zinc-500 border border-white/10 px-8 py-2 rounded-full text-[10px] font-bold uppercase tracking-[0.5em]">Commitment to Excellence</Badge>
            </motion.div>
            <h2 className="text-4xl md:text-6xl font-black uppercase tracking-tighter mb-8 max-w-4xl leading-tight">
              I believe excellence is built through <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-rose-500">knowledge, experience,</span> and giving my absolute best to everything I do.
            </h2>
            <motion.div 
              animate={{ 
                y: [0, 10, 0],
                opacity: [0.3, 0.6, 0.3]
              }}
              transition={{ duration: 3, repeat: Infinity }}
              className="flex flex-col items-center gap-4"
            >
              <div className="h-12 w-px bg-gradient-to-b from-cyan-500 to-transparent" />
            </motion.div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-white/5 py-32 mt-20 bg-black backdrop-blur-3xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-cyan-500/50 to-transparent opacity-20" />
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col items-center gap-16">
            <div className="text-6xl font-black tracking-tighter uppercase text-center group cursor-default">
              Jeet <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-indigo-500 group-hover:from-rose-500 group-hover:to-orange-500 transition-all duration-1000">Rajyaguru</span>
            </div>

            <nav className="flex flex-wrap justify-center gap-x-16 gap-y-8 text-xs font-bold uppercase tracking-[0.4em] text-zinc-500">
              <Link href="#hero" className="hover:text-cyan-400 transition-colors">Home</Link>
              <Link href="#about" className="hover:text-rose-500 transition-colors">Vision</Link>
              <Link href="#skills" className="hover:text-emerald-400 transition-colors">Toolkit</Link>
              <Link href="#projects" className="hover:text-indigo-400 transition-colors">Lab</Link>
              <Link href="#contact" className="hover:text-white transition-colors">Contact</Link>
            </nav>

            <div className="flex flex-col items-center gap-6">
               <p className="text-zinc-700 text-[10px] font-bold uppercase tracking-[0.8em] text-center max-w-xs leading-loose">
                Built with focus and technical excellence.
              </p>
              <p className="text-zinc-800 text-[9px] font-bold uppercase tracking-[1em]">
                © {new Date().getFullYear()}
              </p>
            </div>
          </div>
        </div>
      </footer>

      <style jsx global>{`
        @keyframes gradient-x {
          0%, 100% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
        }
        .animate-gradient-x {
          background-size: 200% 200%;
          animation: gradient-x 15s ease infinite;
        }
        .animate-pulse-slow {
          animation: pulse 8s cubic-bezier(0.4, 0, 0.6, 1) infinite;
        }
        @keyframes pulse {
          0%, 100% { opacity: 0.2; transform: scale(1); }
          50% { opacity: 0.4; transform: scale(1.05); }
        }
        @keyframes scanline {
          0% { transform: translateY(-100%); }
          100% { transform: translateY(200%); }
        }
        .animate-scanline {
          animation: scanline 4s linear infinite;
        }
        .shadow-3xl {
          box-shadow: 0 35px 60px -15px rgba(0, 0, 0, 0.7);
        }
      `}</style>
    </div>
  );
}
