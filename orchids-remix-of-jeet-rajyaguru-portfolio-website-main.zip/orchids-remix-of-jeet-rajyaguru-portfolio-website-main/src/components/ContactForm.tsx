"use client";

import * as React from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { submitContactForm } from "@/app/actions";

const formSchema = z.object({
  name: z.string().min(2, {
    message: "Name must be at least 2 characters.",
  }),
  email: z.string().email({
    message: "Please enter a valid email address.",
  }),
  message: z.string().min(10, {
    message: "Message must be at least 10 characters.",
  }),
});

export function ContactForm() {
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      message: "",
    },
  });

    async function onSubmit(values: z.infer<typeof formSchema>) {
      setIsSubmitting(true);
      try {
        const result = await submitContactForm(values);
        setIsSubmitting(false);

        if (result.success) {
          if ((result as any).emailError) {
            toast.warning("Message saved, but email notification failed. I will still see your message in my dashboard.");
          } else {
            toast.success("Your message has been delivered!");
          }
          form.reset();
        } else {
          toast.error(result.error || "Failed to send message.");
        }
      } catch (error) {
        setIsSubmitting(false);
        toast.error("An unexpected error occurred. Please try again.");
      }
    }

  return (
    <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-zinc-400">Name</FormLabel>
                <FormControl>
                  <Input placeholder="Your Name" disabled={isSubmitting} className="bg-white/5 border-white/10 h-12 rounded-xl focus-visible:ring-indigo-500" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-zinc-400">Email</FormLabel>
                    <FormControl>
                      <Input placeholder="Your Email" disabled={isSubmitting} className="bg-white/5 border-white/10 h-12 rounded-xl focus-visible:ring-indigo-500" {...field} />
                    </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          <FormField
            control={form.control}
            name="message"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-zinc-400">Message</FormLabel>
                <FormControl>
                  <Textarea
                    placeholder="Tell me about your project..."
                    disabled={isSubmitting}
                    className="min-h-[120px] bg-white/5 border-white/10 rounded-xl focus-visible:ring-indigo-500"
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <Button 
            type="submit" 
            disabled={isSubmitting}
            className="w-full h-14 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold transition-all active:scale-95 shadow-[0_0_20px_rgba(79,70,229,0.3)]"
          >
            {isSubmitting ? "Sending..." : "Send Message"}
          </Button>
        </form>

    </Form>
  );
}
