"use client";

import * as React from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";

const navItems = [
  { name: "About", href: "#about" },
  { name: "Skills", href: "#skills" },
  { name: "Projects", href: "#projects" },
  { name: "Contact", href: "#contact" },
];

export function Navbar() {
  const [isOpen, setIsOpen] = React.useState(false);

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className="fixed top-6 left-1/2 -translate-x-1/2 z-50 w-[95%] max-w-4xl"
    >
      <div className="glass rounded-full px-6 py-3 flex items-center justify-between border border-white/10">
          <div className="flex-shrink-0">
              <Link href="/" className="group relative flex items-center px-2 py-1 overflow-visible">
                <motion.div 
                  className="relative flex items-baseline font-black text-4xl tracking-tighter uppercase"
                  whileHover="hover"
                  initial="initial"
                >
                  <motion.span
                    variants={{
                      initial: { y: 0, rotate: 0, scale: 1, color: "#ffffff" },
                      hover: { 
                        y: -5,
                        rotate: -12,
                        scale: 1.1,
                        color: "#818cf8",
                        textShadow: "0 0 20px rgba(129, 140, 248, 0.5)"
                      }
                    }}
                    transition={{ type: "spring", stiffness: 400, damping: 10 }}
                    className="relative z-20"
                  >
                    J
                  </motion.span>
                  <motion.span
                    variants={{
                      initial: { y: 0, rotate: 0, scale: 1, color: "#52525b" },
                      hover: { 
                        y: 5,
                        rotate: 12,
                        scale: 1.1,
                        color: "#ffffff",
                        textShadow: "0 0 20px rgba(255, 255, 255, 0.3)"
                      }
                    }}
                    transition={{ type: "spring", stiffness: 400, damping: 10 }}
                    className="relative z-10 -ml-2"
                  >
                    R
                  </motion.span>
                  
                  {/* Creative Accent Dot */}
                  <motion.div
                    className="absolute -right-4 top-1/2 -translate-y-1/2 h-2.5 w-2.5 rounded-full bg-rose-500"
                    variants={{
                      initial: { scale: 0, opacity: 0 },
                      hover: { 
                        scale: 1, 
                        opacity: 1,
                        boxShadow: "0 0 15px rgba(244, 63, 94, 0.8)",
                        transition: {
                          type: "spring",
                          stiffness: 500,
                          damping: 15
                        }
                      }
                    }}
                  />

                  {/* Dynamic Underline */}
                  <motion.div
                    className="absolute -bottom-1 left-0 h-[3px] bg-gradient-to-r from-indigo-500 via-purple-500 to-rose-500 rounded-full"
                    variants={{
                      initial: { width: 0, opacity: 0 },
                      hover: { width: "100%", opacity: 1 }
                    }}
                    transition={{ type: "spring", stiffness: 300, damping: 25 }}
                  />
                  
                  {/* Glow Effect */}
                  <motion.div
                    className="absolute inset-0 -z-10 bg-indigo-500/20 blur-xl rounded-full"
                    variants={{
                      initial: { scale: 0, opacity: 0 },
                      hover: { scale: 1.5, opacity: 1 }
                    }}
                  />
                </motion.div>
              </Link>
          </div>
        <div className="hidden md:block">
          <div className="flex items-center space-x-8">
            {navItems.map((item) => (
              <Link
                key={item.name}
                href={item.href}
                className="text-sm font-medium text-zinc-400 transition-colors hover:text-white"
              >
                {item.name}
              </Link>
            ))}
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button asChild size="sm" className="rounded-full bg-white text-black hover:bg-cyan-500 hover:text-white transition-all duration-500 font-bold px-6 shadow-[0_0_20px_rgba(255,255,255,0.1)] hover:shadow-[0_0_30px_rgba(6,182,212,0.4)]">
                  <Link href="#contact">Hire Me</Link>
                </Button>
              </motion.div>
          </div>
        </div>
        <div className="md:hidden">
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="inline-flex items-center justify-center rounded-full p-2 text-zinc-400 hover:text-white focus:outline-none"
          >
            {isOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-4 md:hidden glass rounded-3xl p-4 border border-white/10"
        >
          <div className="flex flex-col space-y-2">
            {navItems.map((item) => (
              <Link
                key={item.name}
                href={item.href}
                onClick={() => setIsOpen(false)}
                className="block rounded-2xl px-4 py-3 text-base font-medium text-zinc-400 hover:bg-white/5 hover:text-white transition-colors"
              >
                {item.name}
              </Link>
            ))}
            <div className="pt-2">
              <Button className="w-full rounded-2xl bg-white text-black py-6 text-lg" asChild>
                <Link href="#contact" onClick={() => setIsOpen(false)}>
                  Hire Me
                </Link>
              </Button>
            </div>
          </div>
        </motion.div>
      )}
    </motion.nav>
  );
}
